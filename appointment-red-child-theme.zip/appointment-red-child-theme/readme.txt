Appointment Red is the child theme of Appointment theme. Give it a try you will love it

=== Description ===
A Business theme which is ideal for creating a corporate / business website. Appointment Red theme is a child theme of appointment theme and it is the Red color variation. Appointment Red theme comes with Spanish translation. Other translations / locals yet to come. Theme has couple of extra templates makes it even more powerful.

=== Support ===
For any ideas, support and feedback you can access the theme forum.

== Version ==
1.1.9.2
1. Add alt tag on logo.
1.1.9.1
1. Update string.
1.1.9
1. Fixed copyright footer setting issue.
1.1.8
1. Update string.
1.1.7
1. Update Author URI and Theme URI change http to https secure.
1.1.6
1. Updated Theme Description
1.1.5
1. Update Pagination Color.
1.1.4
1. Updated Strings.
1.1.3
1. Added Spanish Locale
1.1.2
1. Solved Responsive issue.
2. Add Title Tag Support.
3. Update Theme Tag.
1.1.1 Changed Theme URI.
1.1 Add Default pagination
	Solved Styling issue.
1.0.1 Text Domain Issue is resolved.
1.0 Released.