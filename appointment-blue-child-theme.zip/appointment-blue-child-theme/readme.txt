Appointment Blue is the child version of Appointment theme.
@version 1.1.7.2
1. Add alt tag on logo.
@version 1.1.7.1
1. Update string.
@version 1.1.7
1. Update string.
@version 1.1.6
1. Update Author URI and Theme URI change http to https secure.
@version 1.1.5
1. Update Pagination Color.
@version 1.1.4
1. Update theme Description.
@version 1.1.3
1. Added Spanish Locale
@version 1.1.2
1. Solved Responsive issue.
2. Add Title Tag Support.
3. Added Theme Tag.
@version 1.1.1
1. Change Theme URI
@version 1.1
1. Add Default Pagination.
2. Solved Styling issue.


