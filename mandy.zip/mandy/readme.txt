=== Description ===
In this version you will get the theme Mandy color variant. Couple of templates added which is not found in the parent appointment theme.

=== Support ===
For any ideas, support and feedback you can access the theme forum.


Mandy WordPress Theme, Copyright 2016 Webriti Theme
Mandy is distributed under the terms of the GNU GPL

Screenshot Image
URL: http://pixabay.com/en/office-home-office-creative-apple-581131/
Source:http://pixabay.com
License: CC0 Public Domain

== Version ==
------ 1.0 ------
1. Released.

------ 1.0.1 ------ 
1. Solved Theme Review Issue.

------ 1.1 ------
1. Added Theme URI.
2. Update Theme Tag.

------ 1.2 ------
1. Solved Responsive issue.

------ 1.2.1 ------
1. Added Spanish Locale

------ 1.2.2 ------
1. Updated Strings
2. Update theme description.

------ 1.2.3 ------
1. Update Pagiantion Color.

------ 1.2.4 ------
1. Updated Strings

------ 1.2.5 ------
1. Update Author URI and Theme URI to change http to https secure.

------ 1.2.6 ------
1. Update string

------ 1.2.7 ------
1. Update string

------ 1.2.8 ------
Theme Description updated

------ 1.2.9 ------
Add alt tag on logo