Appointment Green is the child theme of Appointment theme. Give it a try you will love it

=== Description ===
A Business theme which is ideal for creating a corporate / business website. Appointment Green theme is a child theme of appointment which has several sections such as slider, services , widget area, etc etc. The green of this theme makes your site looks clean and elegant. Appointment Green theme comes with various locales.

=== Support ===
For any ideas, support and feedback you can access the theme forum.

== Version ==
= 1.1.2 =
1. Add alt tag on logo.
= 1.1.1 =
1. Update string.
= 1.1 =
1. Update string.
= 1.0.9 =
1. Update Author URI and Theme URI change http to https secure.
= 1.0.8 =
1. Updated Strings
= 1.0.7 =
1. Update Pagination Color.
= 1.0.6 =
1. Update theme description.
= 1.0.5 =
1. Added Spanish Locale
= 1.0.4 =
1. Solved Responsive issue.
2. Add Title Tag Support.
3. Added Theme Tag.
= 1.0.3 =
1. Changes Theme URI
= 1.0.2 =
1. Solved styling issue.
= 1.0.1 =
1. Removed Blog and Left sidebar Templates
2. Added scripts perfix to appointment-green
3. Added Text Domain as appointment-green in style.css file.
4. Updated Description.
1.0 Released
